var express = require('express');
var router = express.Router();

router.URL_React ='http://localhost:3001/#/'

router.URL_Node ='http://localhost:3000/';

module.exports = router;
