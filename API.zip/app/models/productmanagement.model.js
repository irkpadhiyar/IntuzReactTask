var db = require('../../config/database');
var dbFunc = require('../../config/db-function');

var productManagementModel = {
    getProductList: getProductList
}

function getProductList(data) {
    return new Promise((resolve, reject) => {
        var query = 'SELECT * FROM products';
        
        db.query(query, (error, rows) => {
            if (error) {
                dbFunc.connectionRelease;
                reject(error);
            } else {
                dbFunc.connectionRelease;
                resolve(rows);
            }
        });
    });
}

module.exports = productManagementModel;

