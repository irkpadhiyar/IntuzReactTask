var productmanagementModel = require("../models/productmanagement.model");

var productmanagementService = {
    getProductList: getProductList,
}

function getProductList(reqData) {
    return new Promise((resolve,reject) => {
        productmanagementModel.getProductList(reqData).then((data)=>{
            resolve(data);
        }).catch((err) => {
            reject(err);
        })
    });
}

module.exports = productmanagementService;

