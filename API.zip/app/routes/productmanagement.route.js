const productmanagementService = require('../services/productmanagement.service');

function init(router) {
    router.route('/getProductList').post(getProductList);
}

function getProductList(req,res) {
  productmanagementService.getProductList(req.body).then((data) => {
      if(data) {
        res.json({
          "success": true,
          "data": data
        });
      }
    }).catch((err) => {
      res.send(err);
    });
}

module.exports.init = init;
