const mysql = require('mysql');
mysql.createConnection({multipleStatements: true});
module.exports = mysql.createPool({
    connectionLimit : 100,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'intuzreacttask'
})




