var express = require("express");
var app = express();
i18n = require("i18n");
var path = require('path');
var cookieParser = require('cookie-parser');
var cors = require('cors');
var bodyParser = require('body-parser');
var multer = require("multer");

var dbfunc = require('./db-function');
var checkToken = require('./secureRoute');

var ProductManagement = require('../app/routes/productmanagement.route');

dbfunc.connectionCheck.then((data) => {
  //console.log(data);
}).catch((err) => {
  console.log(err);
});

i18n.configure({
  locales: ['en', 'de'],
  directory: path.resolve("./locales")
});


app.use(cors());

app.use(function (req, res, next) {
  i18n.setLocale(req.headers["accept-language"] != undefined ? req.headers["accept-language"] : res.headers["accept-language"])
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.use(bodyParser.json({limit: '100mb'}));
app.use(bodyParser.urlencoded({limit: '100mb', extended: true}));

var router = express.Router();
app.use('/api', router);
ProductManagement.init(router);
var secureApi = express.Router();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, '../document')));
app.use(express.static(path.join(__dirname, '../Html')));

//body parser middleware
app.use('/secureApi', secureApi);
secureApi.use(checkToken);

app.use(function (err, req, res, next) {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});


// index route
app.get('/', (req, res) => {
  res.send(i18n.__("User_Not_Found"));
});

var ApiConfig = {
  app: app
}

ProductManagement.init(secureApi);

module.exports = ApiConfig;
