var hbs = require('nodemailer-express-handlebars');
var email = process.env.MAILER_EMAIL_ID || 'renewals@yachtsman.ie';
var pass = process.env.MAILER_PASSWORD || 'Dad74242';
var nodemailer = require('nodemailer');
var path = require('path');
var UtilityModel = require('../app/models/utility.model');

var smtpTransport = nodemailer.createTransport({
    // service: process.env.MAILER_SERVICE_PROVIDER || 'hostgator',
    // name: process.env.MAILER_NAME || 'hostgator',
    // host: 'mail.cognisun.com',
    // port: 465,
    // tls : {
    //     rejectUnauthorized: false
    // },
    // secure: true,
    // service: 'outlook',
    // name: process.env.MAILER_NAME || 'outlook',
    // debug: true,
    // logger: true,
    // secure: false,
    host: 'smtp.office365.com',
    port: 587,
    StartTLS: true,
    // tls : {
    //     // rejectUnauthorized: false,
    //     ciphers:'STARTTLS'

    // },
    secureConnection: false,
    auth: {
        user: email,
        pass: pass
    }
});

var smtpTransport_eng = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    StartTLS: true,
    secureConnection: false,
    auth: {
        user: email,
        pass: pass
    }
});
var smtpTransport_spanish = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    StartTLS: true,
    secureConnection: false,
    auth: {
        user: 'ventas@yachtsman.es',
        pass: 'Wuj86202'
    }
});
var smtpTransport_english = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    StartTLS: true,
    secureConnection: false,
    auth: {
        user: 'yachtsupport@yachtsman.ie',
        pass: 'Yacht461'
    }
});
const handlebarOptions = {
    viewEngine: {
        extName: ".html",
        partialsDir: path.resolve("./app/templates/"),
        defaultLayout: false        // <-----   added this
    },
    viewPath: path.resolve("./app/templates/"),
    extName: ".html"
};

smtpTransport.use('compile', hbs(handlebarOptions));
smtpTransport_english.use('compile', hbs(handlebarOptions));
smtpTransport_spanish.use('compile', hbs(handlebarOptions));

function mail(data) {
    return new Promise((resolve, reject) => {
        if (data.DocLang) {
            if (data.DocLang == 'English') {
                smtpTransport_english.sendMail(data, function (err) {
                    console.log("eeeeeee", err);
                    if (!err) {
                        resolve();
                    } else {
                        UtilityModel.SaveException(err, 'mail');
                        reject(err);
                    }
                });
            }
            else if (data.DocLang == 'Spanish') {
                smtpTransport_spanish.sendMail(data, function (err) {
                    console.log("eeeeeee", err);
                    if (!err) {
                        resolve();
                    } else {
                        UtilityModel.SaveException(err, 'mail');
                        reject(err);
                    }
                });
            }
        }
        else {
            smtpTransport.sendMail(data, function (err) {
                console.log("eeeeeee", err);
                if (!err) {
                    resolve();
                } else {
                    UtilityModel.SaveException(err, 'mail');
                    reject(err);
                }
            });
        }

    });
}

module.exports = {
    mail: mail
}
