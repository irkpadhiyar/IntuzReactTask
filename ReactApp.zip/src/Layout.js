import React from 'react'
import { Switch } from 'react-router-dom'
import './App.scss';
import { UnauthenticatedRoute, AuthenticatedRoute } from './utils/authenticate'
import PropTypes from 'prop-types';

const DefaultLayout = React.lazy(() => import('./containers/DefaultLayout'));

class Layout extends React.Component {

	constructor(props) {
		super(props)

		this.state = {
			timeout: 1000 * 3600 * 1 * 8, //(60*60*8 secound) for 8 hour for showing alert
			showModal: false,
			userLoggedIn: false,
			isTimedOut: false,
			sessiondisable: false
		}

		this.idleTimer = null
		this.onAction = this._onAction.bind(this)
		this.onActive = this._onActive.bind(this)
		this.onIdle = this._onIdle.bind(this)
		this.handleClose = this.handleClose.bind(this)
		this.handleLogout = this.handleLogout.bind(this)
	}

	_onAction(e) {
		// console.log('user did something', e)
		this.setState({ isTimedOut: false })
	}

	_onActive(e) {
		// console.log('user is active', e)
		this.setState({ isTimedOut: false })
	}

	_onIdle(e) {
		// console.log('user is idle', e)
		const isTimedOut = this.state.isTimedOut
		if (isTimedOut) {
			localStorage.clear()
			this.props.history.push('/login')
		} else {
			this.setState({ showModal: true })
			this.idleTimer.reset();
			this.setState({ isTimedOut: true })
			this.setState({ sessiondisable: true })
			setTimeout(() => {
				if (this.state.sessiondisable) {
					localStorage.clear()
					this.props.history.push('/login')
				}
			}, 900000);//15 min alert logout
		}

	}

	handleClose() {
		this.setState({ sessiondisable: false })
		this.setState({ showModal: false })
	}

	handleLogout() {
		this.setState({ showModal: false })
		localStorage.clear()
		this.props.history.push('/login')
	}

	render() {
		const { match } = this.props
		return (
			<>
				<div className="">
					<Switch>
						<UnauthenticatedRoute path="/" name="Home" component={DefaultLayout} />
					</Switch>
				</div>
			</>
		)
	}

}

Layout.propTypes = {
	match: PropTypes.any.isRequired,
	history: PropTypes.func.isRequired
}

export default Layout