const apiBase = 'http://localhost:3000/'; 

export {apiBase};