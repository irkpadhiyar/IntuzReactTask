import React from 'react';
import { Route,Redirect } from 'react-router-dom';
import Cookies from 'js-cookie';
export const getAccessToken = () => localStorage.getItem('access_token');
export const getRefreshToken = () =>  localStorage.getItem('refresh_token');
export const isAuthenticated = () => !!getAccessToken()

export const UnauthenticatedRoute = ({ component: Component, ...rest }) => (
    <Route {...rest} render={(props) => (
        !isAuthenticated()
            ? <Component {...props} />
            : <Redirect to='/' />
    )} />
);

export const AuthenticatedRoute = ({ component: Component, ...rest }) => (
    <Route {...rest} render={(props) => (
        isAuthenticated()
            ? <Component {...props} />
            : <Redirect to='/login' />
    )} />
);