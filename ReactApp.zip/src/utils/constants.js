﻿import React from 'react';

//=============PATH=================//
export default class APIConstant {

    static path = {
    }

    static requestKeys = {
        login: {
            username: 'username',
            password: 'password'
        }
    }

    static responseKeys = {
        data: 'data',
        settings: 'settings',
        statusCode: 'code'
    }

};

//============Common Configurations========//

export class CommonConfig {

    static appVerison = "V1.0";
    static appRegion = "DEV";

    static isEmpty = function (value) {
        if (value === undefined || value === null || value === '') {
            return true;
        } else {
            if (typeof value === 'string') {
                return value.trim() == "";
            } else {
                return false;
            }
        }
    }

    static handleError = function (error, methodName, userMessageKey, severity) {
    }

    static dateFormat = {
        dateTime: 'DD/MM/YYYY HH:mm',
        dateOnly: 'DD/MM/YYYY',
        // forDatePicker: 'YYYY-MM-DD',
        forDatePicker: 'DD-MM-YYYY',
        yearOnly: 'YYYY',
        dbDateTime: 'YYYY-MM-DD HH:mm:ss',
        timeOnly: 'HH:mm'
    }

    static dataTableConfig = {
        rowsPerPage: 10,
        rowsPerPageOptions: [5, 10, 20, 30, 50],
        columnToggleIcon: <i className="fa fa-bars"></i>
    }

    static RegExp = {

        percentage: /(^100(\.0{1,2})?$)|(^([1-9]([0-9])?|0)(\.[0-9]{1,2})?$)/,
        percentageWithNegative: /^-?[0-9]{0,2}(\.[0-9]{1,2})?$|^-?(100)(\.[0]{1,2})?$/,
        number: /^[0-9]+$/,
        // nameWithoutSpace: /^[a-zA-Z]+[a-zA-Z-']*$/,
        // nameWithSpace: /^[a-zA-Z]+[a-zA-Z-\s']*$/,
        nameWithoutSpace: /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]+[a-zA-Z-\u00C0-\u024F\u1E00-\u1EFF']*$/,
        nameWithSpace: /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]+[a-zA-Z-\u00C0-\u024F\u1E00-\u1EFF\s']*$/,
        email: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/, // /^(?=.*[0-9])(?=.*[!@#$%^&*.])[a-zA-Z0-9!@#$%^&*.]{8,}$/,
        decimal: /^[0-9]+(\.[0-9][0-9])?$/,
        decimalWithOne: /^(?:\d*\.\d{1,2}|\d+)$/,
        decimalWithNegative: /^-?(?:\d*\.\d{1,2}|\d+)$/,  /*   /^-?[0-9]+(\.[0-9][0-9])?$/  */
        // alphaNumeric: /^[a-zA-Z0-9]+[a-zA-Z0-9-\s']*$/,
        alphaNumeric: /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF0-9]+[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF0-9-\s']*$/,
        year: /^[0-9]{4}$/,
        allowAllWithSpace: /^(\w.*)$/,
        latlng: /^-?(\d*\.)?\d+$/,
    }

    static thousandSeparator = {
        format: toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }
}