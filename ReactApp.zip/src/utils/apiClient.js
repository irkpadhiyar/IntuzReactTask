import axios from 'axios';
import i18n from "i18next";
import { apiBase } from './config';
import { getAccessToken } from './authenticate';

const instance = axios.create({
  baseURL: apiBase,
});

var headers = {
  'Content-Type': 'application/json',
  'Authorization': 'JWT fefege...',
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"*",
  'X-Requested-With': 'XMLHttpRequest'
}

//axios.defaults.headers.common['Authorization'] =sessionStorage.getItem("token");
const request = (method, url, data, isSilent) => {
  // console.log("SDAf", getAccessToken())
  headers['accept-language'] = i18n.language;
  headers['token'] = getAccessToken();
  let isaSilent = isSilent === undefined ? false : isSilent

  // instance.defaults.headers.common['Auth  orization'] = sessionStorage.getItem("token");
  if (typeof isaSilent === "boolean" && isaSilent !== true) {
  }

  return new Promise((resolve, reject) => {
    (() => {
      if (method === 'get') {
        return instance.request({
          url, method, params: data, headers: headers
        });
      } else {
        return instance.request({
          url, method, data, headers: headers
        });
      }
    })()
      .then((res) => {
        resolve(res.data);
      })
      .catch((err) => {
        reject(err.response);
      })
      ;
  });
};

export default {
  get: (endpoint, data, isSilent) => {
    return request('get', endpoint, data, isSilent);
  },
  post: (endpoint, data, isSilent) => {
    return request('post', endpoint, data, isSilent);
  },
  put: (endpoint, data, isSilent) => {
    return request('put', endpoint, data, isSilent);
  },
  del: (endpoint, data, isSilent) => {
    return request('delete', endpoint, data, isSilent);
  },
};


