
import ProductManagement from './views/Pages/ProductManagement';

const routes = [
  { path: '/', exact: true, name: 'Product List', component: ProductManagement },
];

export default routes;
