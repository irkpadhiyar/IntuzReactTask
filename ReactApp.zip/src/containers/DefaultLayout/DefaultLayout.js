import React, { Component, Suspense } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import { Container } from 'reactstrap';

import {
  AppAside,
  AppFooter,
  AppHeader,
} from '@coreui/react';

import routes from '../../routes';

const DefaultAside = React.lazy(() => import('./DefaultAside'));
const DefaultFooter = React.lazy(() => import('./DefaultFooter'));
const DefaultHeader = React.lazy(() => import('./DefaultHeader'));

class DefaultLayout extends Component {

  loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>

  signOut(e) {
    e.preventDefault();
    localStorage.removeItem('access_token');
    localStorage.removeItem('loggedInUserData');
    this.props.history.push('/login');
  }

  componentDidMount() {
    document.body.classList.remove('brand-minimized');
    window.scrollTo(0, 0);
  }

  mouseEnterSidebar() {
    var isExist = document.body.classList.contains("sidebar-minimized");
    if (isExist !== 1) {
      document.body.classList.remove('sidebar-minimized');
      document.body.classList.remove('brand-minimized');
    }
  }
  mouseLeaveSidebar() {
    document.body.classList.add('sidebar-minimized');
    document.body.classList.remove('brand-minimized');
  }

  render() {
    return (
      <div className="app">
        <AppHeader fixed>
          <Suspense  fallback={this.loading()}>
            <DefaultHeader {...this.props}
              onLogout={e => this.signOut(e)} 
            />
          </Suspense>
        </AppHeader>
        
        <div className="app-body">
          <main className="main">

            <Container fluid>
              <Suspense fallback={this.loading()}>
                <Switch>
                  {routes.map((route, idx) => {
                    return route.component ? (
                      <Route
                        key={idx}
                        path={route.path}
                        exact={route.exact}
                        name={route.name}
                        render={props => (
                          <route.component {...props} />
                        )} />
                    ) : (null);
                  })}
                  <Redirect from="/" to="/dashboard" />
                </Switch>
              </Suspense>
            </Container>
          </main>
          
          <AppAside fixed>
            <Suspense fallback={this.loading()}>
              <DefaultAside />
            </Suspense>
          </AppAside>
        </div>
        
        <AppFooter>
          <Suspense fallback={this.loading()}>
            <DefaultFooter />
          </Suspense>
        </AppFooter>
      </div>
    );
  }
}

export default DefaultLayout;