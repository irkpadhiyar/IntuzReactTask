import React, { Component } from 'react';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import api from '../../utils/apiClient';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button'

class ProductManagement extends Component {

  constructor(props) {
    super(props);
    this.state = {
      ProductList: []
    };
  }

  componentDidMount() {
    this.getProductList();
  }

  getProductList() {
    try {
      let data = {};
      api.post('api/getProductList', data).then(res => {
        console.log("getContactList----------------- ", res);
        if (res.success) {
          let formattedData = res.data;
          this.setState({ ProductList: formattedData });
        } else {
          console.log("getProductList", res);
        }
      }).catch(err => {
        console.log("getProductList", err);
      });
    } catch (err) {
      console.log("getProductList", err);
    }
  }

  render() {

    return (
      <div>

        <div>
          {
            this.state.ProductList.map((ct, i) => {
              return (
                <Card title={ct.name} subTitle={ct.price} className="ui-card-shadow" style={{ width: "250px" , display: 'inline-block', margin: "10px"}}>
                  <div>{ct.description}</div>
                </Card>
              )
            })
          }
        </div>


      </div>
    );
  }
}

export default ProductManagement;